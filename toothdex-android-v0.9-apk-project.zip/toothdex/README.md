# ToothDex Android — version 0.9

Projet Android prêt à compiler, intégrant la version web ToothDex v0.9 (parc, avatar personnalisable, vestiaire et choix du compagnon parmi les Pokémon débloqués).

## Important

- **Ce ZIP contient le projet source, pas un APK déjà compilé.** Il faut lancer la compilation via Android Studio ou GitHub Actions.
- Ne remplace pas les fichiers racine de ton site GitHub Pages par ceux-ci : ce projet Android est distinct de la version web.
- La progression est conservée localement dans l'application Android. Elle n'est pas automatiquement synchronisée avec le navigateur web.
- Les sprites Pokémon sont chargés depuis Internet ; la première ouverture nécessite une connexion pour les images.

## Méthode 1 — Android Studio

1. Décompresse l'archive.
2. Ouvre le dossier `toothdex` dans Android Studio.
3. Attends la synchronisation Gradle.
4. Va dans **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. L'APK debug se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.

## Méthode 2 — GitHub Actions

Le workflow `.github/workflows/build-apk.yml` compile automatiquement un APK debug après un push sur `main`/`master`, ou manuellement depuis l'onglet **Actions** via **Build ToothDex APK > Run workflow**.

À la fin, ouvre l'exécution réussie et télécharge l'artefact `toothdex-debug-apk`, puis extrais `app-debug.apk`.

L'APK debug est destiné aux essais et n'est pas signé pour une publication Play Store.
